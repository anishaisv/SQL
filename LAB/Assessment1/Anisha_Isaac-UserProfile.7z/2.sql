select Account_Name from user_data where Gender='Female' and Date_Joined < '2020-01-01';

