select Gender,sum(Likes) as Total_Likes from user_data group by Gender

