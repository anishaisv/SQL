select sum(Posts) as Total_Posts from user_data
