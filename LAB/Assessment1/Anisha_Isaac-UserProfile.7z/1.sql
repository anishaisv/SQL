select Account_Name,Followers from user_data order by Followers desc
