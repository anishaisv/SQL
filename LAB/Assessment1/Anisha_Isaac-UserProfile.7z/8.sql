select top 3 Account_Name,Likes from user_data order by Likes Desc
