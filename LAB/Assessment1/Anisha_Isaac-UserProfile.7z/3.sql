select Account_Name,Posts,Likes from user_data where Posts>100 and Likes<500
