select count(*) as User_Count from user_data where Date_Joined>'2020-01-01'

